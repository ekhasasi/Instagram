<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindulu");
}
include "koneksi.php";
$sql = "SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instagram</title>
    <link rel="shortcut icon" href="drink.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        .geeks {
            width: 286px;
            height: 250px;
            overflow: hidden;
            margin: 0 auto;
        }

        .geeks img {
            width:100%;
            transition: 0.5s all ease-in-out;
        }

        .geeks:hover img {
            transform:scale(1.5);
        }
    </style>
</head>
<style>
        body{
        background-image: url(/proyek_ig/lautan.jpg);
        background-size: cover;
        background-repeat:no-repeat;


      }
    </style>
      <br>

<nav class="navbar fixed-top" style="background-color: #e3f2fd;">
    <div class="container-fluid">
      <img src="logo.png" alt="" width="50" height="50" class="d-inline-block align-text-top">
        INSTAGRAM 
    <div>
          <ul class="list-inlist">
              <li class="list-inline-item">
                <a href="tambah.php"> 
                    <button class="btn btn-success">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-plus-square-fill" viewBox="0 0 16 16">
                            <path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm6.5 4.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3a.5.5 0 0 1 1 0z"/>
                        </svg>
                    </button>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="logout.php">
                    <button class="btn btn-secondary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-box-arrow-right" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0v2z"/>
                            <path fill-rule="evenodd" d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
                        </svg>
                    </button>
                </a>
              </li>
          </ul>
      </div>
    
    
    
  </div>
  </nav>
  
  <center>
    <div class="container">
    <?php while($post = mysqli_fetch_assoc($query)) { ?>

    <br><div class="card mt-3" style="width: 18rem;">
    <div class="geeks">
    <img class="card-img-top" src="images/<?= $post['foto'] ?>" alt="Card image cap">
    </div>
    <div class="card-body">
    </div>
        
    <ul class="list-group list-group-flush">
    <li class="list-group-item"><?= $post['caption'] ?></li>
    <li class="list-group-item"><?= $post['lokasi'] ?></li>
    </ul>
    <div class="card-body">
    <a href="hapus.php?no=<?= $post['no'] ?>"><i class="fa fa-trash" style="font-size:24px"></i></a>
    <a href="edit.php?no=<?= $post['no'] ?>"><i class="fa fa-pencil" style="font-size:24px"></i></a>
    </div>
    </div>
    <br>
   

    <?php } ?>

    

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel"></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        
        <label for="" class="form-label">foto</label><br>
        <input class="form-control" type="file" name="foto" id="" required><br><br>

        <label for="" class="form-label">Caption</label><br>
        <input class="form-control" type="text" name="caption" id="" autocomplete="off"><br>

        <label for="" class="form-label">Lokasi</label><br>
        <input class="form-control" type="text" name="lokasi" id="" autocomplete="off"><br><br>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <input type="submit" class="btn btn-primary" value="Tambah" name="Posting"></button>
        </div>
    </form>
      </div>
    </div>
  </div>
</div>
    </div>
    </center>

    !-- Modal edit -->

<div class="modal fade" id="modalEdit<?= $post['no']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModaltable">Edit drink</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
      <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">
      <label for="" class="form-label">Foto</label>
    <input type="file" class="form-control" name="foto" id="" value="<?= $post['foto'] ?>"><br>
    <img src="data/<?= $post['foto'] ?>" width="100" alt=""><br><br>
    <label for="" class="form-label">Caption</label><br>
    <input type="" class="form-control" name="caption" id="" value="<?= $post['caption'] ?>" autocomplete="off"><br>
    <label for="" class="form-label">Lokasi</label><br>
    <input type="" class="form-control" name="lokasi" id=""  value="<?= $post['lokasi'] ?>" autocomplete="off"><br>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Edit" name="Update"></button>
      </div>
    </div>
  </div>
</div>
  </div>

  
    </center>
</body>
</html>
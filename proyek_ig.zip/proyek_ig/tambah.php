<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drink</title>
    <link rel="shortcut icon" href="IKarya.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<style>
        body{
        background-image: url(/proyek_ig/lautan.jpg);
        background-size: cover;
        background-repeat:no-repeat;


      }
    </style>
    <div class="container">
    <h1 align="center"> drink  </h1>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <form action="proses_tambah.php" method="post" enctype="multipart/form-data">

    <form>
    <div class="mb-3">
    <label for="" class="form-label">pictures</label>
    <input type="file" class="form-control" name="foto" id="" required>
     </div>

    <div class="mb-3">
    <label for="" class="form-label">caption</label>
    <input type="" class="form-control" name="caption" id="" autocomplete="off">
    </div>

    <div class="mb-3">
    <label for="" class="form-label">ᥣocation</label>
    <input type="" class="form-control"  name="lokasi" id="" autocomplete="off">
    </div>

    <button type="submit" class="btn btn-primary" value="Posting" name="Posting">upload</button>

    </form>
    </div>
</body>
</html>

